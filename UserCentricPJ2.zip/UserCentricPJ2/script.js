const searchForm = document.getElementById('search-form');
const searchInput = document.getElementById('search-input');
const searchButton = document.querySelector('.search-button'); 

const pageMapping = {
    "malaysia": "malaysia.html",
    "Malaysia": "Malaysia.html",
};
searchInput.addEventListener('keyup', function(event) {
    if (event.key === 'Enter') {
      searchButton.click(); 
    }
  });
searchButton.addEventListener('click', () => {  
    const searchTerm = searchInput.value.toLowerCase();

    if (pageMapping[searchTerm]) {
        window.location.href = pageMapping[searchTerm];
    } else {
        alert("Page not found!");
    }
});